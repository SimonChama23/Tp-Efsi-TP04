import { useState } from "react";
import Form from "./Form";
import Card from "./Card";
    const App = () => {
    const [Cards, setCard] = useState([]);
    const addCard = (info) =>
    {
      const newCard = 
      {
       id: new Date().getTime(),
       info: info,
      };
      setCards([...cards, newCard])
    };
      const deleteCard = (id) => {
      const newCards = card.filter((card) => card.id !== id)
      setCards(newCards);
    }
    return (
     <div>     
     <Form onAddCard={addCard}/>
     <div className="one-half column">
     <h1 className="text-center mb-4">App Cards</h1>
     {
     card.map((card) => (<tarjeta key={card.id} onData={card.info}  onDeleteData={() => deleteCard(card.id)}/> ))
     }
     </div>
     </div>
    )
    }
    export default App;