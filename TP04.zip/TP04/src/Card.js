function Card({onData, onDeleteData}) {

  const handleDelete = () =>{
    onDeleteData()
  }
  return (
    <div className="date">
      <p>Pet: <span>{onData.Pet}</span></p>

      <p>Owner: <span>{onData.Owner}</span></p>

      <p>Date: <span>{onData.Date}</span></p>

      <p>Hour: <span>{onData.Hour}</span></p>

      <p>Symptoms: <span>{onData.Symptoms}</span></p><button onClick={handleDelete} className="button delete u-full-width">Delete ×</button>
    </div>
    )       
}
export default Card;