const Form = ({ onAddCard}) => {
    var dateMin = new Date();
    var day = dateMin.getDate();
    var mouth = dateMin.getMonth() + 1;
    var year = dateMin.getFullYear();
    var date1
    if(mouth > 0 && mouth < 12)
    {
    date1 = String( year + "-" + mouth + "-" + day)
    }
    else 
    {
    console.log("Try again")
    }
   
    const handleSubmit = (e) => {
    e.preventDefault();
    const data = new FormData(e.target)
    const newDate = {
      pet: data.get("pet"),
      owner: data.get("owner"),
      date: data.get("date"),
      hour: data.get("hour"),
      symptoms: data.get("symptoms"),
    }
    onAddCard(newDate)
    }
return (
    <div> <div className="one-half column">
    <h2>Creat my date</h2>
    <form onSubmit={handleSubmit}>
      <label>PetName</label><input type="text" name="pet" className="u-full-width"placeholder="Pet name" required />
      <label>OwnerName</label><input type="text" name="owner" className="u-full-width" placeholder="Name of the owner of the pet" required />
      <label>Date</label><input type="date" name="date"className="u-full-width" required min="2023-05-29" max="2080-12-31"/>
      <label>Hour</label><input type="time" name="hour" className="u-full-width" required max="19:00:00" min="08:00:00"/>
      <label>symptoms</label><texttask name="symptoms" className="u-full-width" required>
      </texttask>
      <button type="submit"className="u-full-width button-primary">Add Date</button></form>
  </div>
 </div>
    );
}
export default Form;